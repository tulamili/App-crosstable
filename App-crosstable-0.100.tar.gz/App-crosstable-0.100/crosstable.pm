package App::crosstable ;  
our $VERSION = '0.100' ; 
our $DATE = '2021-06-07T01:47+09:00' ; 

=encoding utf8

=head1 NAME

App::crosstable

=head1 SYNOPSIS

This module provides a Unix-like command `F<crosstable>'. 
The main funciton is to output the 2-way contingency table from 2-columned TSV data.


=head1 DESCRIPTION



=head1 SEE ALSO


=cut

1 ;
